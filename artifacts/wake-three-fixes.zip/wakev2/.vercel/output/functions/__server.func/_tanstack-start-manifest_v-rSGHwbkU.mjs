//#region node_modules/.nitro/vite/services/ssr/assets/_tanstack-start-manifest_v-rSGHwbkU.js
var tsrStartManifest = () => ({ routes: {
	__root__: {
		filePath: "/workspace/src/routes/__root.tsx",
		children: ["/"],
		preloads: ["/assets/index-eF2U6yvr.js"],
		scripts: [{ attrs: {
			type: "module",
			async: !0,
			src: "/assets/index-eF2U6yvr.js"
		} }]
	},
	"/": {
		filePath: "/workspace/src/routes/index.tsx",
		children: void 0,
		preloads: ["/assets/routes-CSAhMv7X.js"]
	}
} });
//#endregion
export { tsrStartManifest };
